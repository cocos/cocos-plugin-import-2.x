# plugin-import-2.x

[中文](https://github.com/cocos-creator/plugin-import-2.x/blob/main/README.md)

This plugin is used to reduce the workload of developers upgrading v2.x projects to v3.0.0.

As the editor does not currently support hot updates for plugins, if developers encounter problems with the plugin, use the tutorial below to update the plugin so that they can quickly fix the problem without having to wait for the editor version to be updated.

## How to update the plugin

1. Download [zip](https://github.com/cocos-creator/plugin-import-2.x/archive/v1.0.zip) or [tar.gz](https://github.com/cocos-creator/plugin-import-2.x/archive/v1.0.tar.gz) extension packages。

2. Store in the relevant designated location, as follows
    - To apply globally (all projects), just store the plugins folder under **User/.CocosCreator/extensions**
    - To apply to a single project, simply store the folder in the **extensions** folder at the same level as the **assets** file
    
> **Note**: If you do not have an **extensions** folder, you will need to create one yourself
    

3. Enable Extension
    
    1.Open Extension Manager via the main menu
    
    <img src="./image/main-menu.png" width="20%" height="20%"/>
    
    2.Click on the Refresh button
    
    <img style="margin-left: 84px" src="./image/update.png" width="50%" height="50%"/> 
    
    3.Enable extension
    
    <img style="margin-left: 110px" src="./image/open.png" width="50%" height="50%"/>
    
> **NOTE**: If 2 menus appear, restart the editor. (This is a known issue and will be fixed later)    

## How to give feedback

1. [New **New issue**](https://github.com/cocos-creator/plugin-import-2.x/issues/new) 
2. [Forum](https://forum.cocos.org/c/Creator)
