'use strict';

const { join } = require('path');

exports['build-typescript-develop'] = async function() {
    return [
        __dirname,
    ];
};

exports['build-less-develop'] = function() {
    return [];
};
